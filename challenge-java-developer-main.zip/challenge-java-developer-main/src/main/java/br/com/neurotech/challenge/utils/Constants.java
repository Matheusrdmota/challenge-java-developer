package br.com.neurotech.challenge.utils;

public class Constants {
    public static final String INVALID_PARAMS_ERROR_MESSAGE = "Os parâmetros informados são inválidos!";
    public static final String INTERNAL_SERVER_ERROR_MESSAGE = "Houve um erro interno! Tente novamente mais tarde!";
}
