package br.com.neurotech.challenge.exception;

public class InvalidParamException extends RuntimeException{
    public InvalidParamException() {}
}
