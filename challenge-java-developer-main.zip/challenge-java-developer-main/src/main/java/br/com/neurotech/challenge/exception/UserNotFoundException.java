package br.com.neurotech.challenge.exception;

public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException() {}
}
