package br.com.neurotech.challenge.entity;

public enum VehicleModel {
	HATCH,
	SUV
}

